package game;

import city.cs.engine.*;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import javax.swing.ImageIcon;

public class Background extends UserView {

    private Image background;
    private Boo boo;
    private Game game;
    Image image;

    public Background(World world, Game game, int width, int height) {
        super(world, width, height);
        this.game = game;
        background = new ImageIcon("data/background.png").getImage();
    }

    @Override
    protected void paintBackground(Graphics2D g) {
        g.drawImage(background, 0, 0, this);
    }

    @Override
    protected void paintForeground(Graphics2D g) {
        g.setColor(Color.white);
        g.drawString("Score:     x" + this.game.getBoo().getCoinsCount(), 10, 25);
        ImageIcon i = new ImageIcon("data/coins.gif");
        image = i.getImage();
        g.drawImage(image, 45, 10, 80, 40, 0, 0, 400, 400, this);

        g.setColor(Color.white);
        g.drawString("Lives:      x" + this.game.getBoo().getLivesCount(), 10, 50);
        ImageIcon i2 = new ImageIcon("data/oneup.png");
        image = i2.getImage();
        g.drawImage(image, 47, 35, 80, 70, 0, 0, 400, 400, this);
    }
}

/* this class stores the background as well as displays the information of the 
score and lives */
