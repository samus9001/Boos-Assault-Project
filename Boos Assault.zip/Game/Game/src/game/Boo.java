package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Boo extends Walker {

    private static final Shape booShape = new PolygonShape(
            -0.64f, -1.39f, 0.76f, -1.4f, 1.95f, -0.41f, 1.94f, 0.96f, 0.31f, 1.49f, -0.41f, 1.49f, -1.93f, 0.92f, -1.94f, -0.39f);
    private static final BodyImage image
            = new BodyImage("data/boo.gif", 3f);

    private static int livesCount;
    private int coinsCount;

    public Boo(World world) {
        super(world, booShape);
        addImage(image);
        livesCount = 1;
        coinsCount = 0;
    }

    public int getLivesCount() {
        return livesCount;
    }

    public void incrementLives() {
        livesCount++;
    }

    public void decrementLives() {
        livesCount--;
        if (livesCount == 0) {
            System.exit(0);
            System.out.print("Game Over");
        }
    }

    public int getCoinsCount() {
        return coinsCount;
    }

    public void incrementCoinsCount() {
        coinsCount++;
    }
}

// this class creates boo as well as changes to the score and lives
