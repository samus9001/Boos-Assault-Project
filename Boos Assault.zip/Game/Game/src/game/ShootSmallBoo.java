package game;

import city.cs.engine.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import org.jbox2d.common.Vec2;

public class ShootSmallBoo extends MouseAdapter {

    private WorldView view;

    public ShootSmallBoo(WorldView view) {
        this.view = view;
    }

    @Override
    public void mousePressed(MouseEvent e) {
        DynamicBody smallboo = new SmallBoo(view.getWorld());
        smallboo.setPosition(view.viewToWorld(e.getPoint()));
        smallboo.setLinearVelocity(new Vec2(10, 3.5f));
    }

}

// this class allows the projectile boo to be shot when the mouse is pressed
