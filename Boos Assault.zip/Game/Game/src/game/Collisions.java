package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Collisions implements CollisionListener {

    private Boo boo;
    private Yoshi yoshi;
    private Toad toad;
    private SmallBoo smallboo;

    public Collisions(Boo boo) {
        this.boo = boo;
    }

    public Collisions(Yoshi yoshi) {
        this.yoshi = yoshi;
    }

    public Collisions(SmallBoo smallboo) {
        this.smallboo = smallboo;
    }

    @Override
    public void collide(CollisionEvent e) {

        if (e.getOtherBody() == yoshi) {
            yoshi.incrementCoinsCount();
            e.getReportingBody().destroy();
        }

        if (e.getOtherBody() == boo) {
            if (e.getReportingBody() instanceof Coins) {
                boo.incrementCoinsCount();
                e.getReportingBody().destroy();

            } else if (e.getReportingBody() instanceof Yoshi) {
                boo.decrementLives();
                e.getReportingBody().destroy();

            } else if (e.getReportingBody() instanceof Toad) {
                boo.decrementLives();
                e.getReportingBody().destroy();

            } else if (e.getReportingBody() instanceof Lives) {
                boo.incrementLives();
                e.getReportingBody().destroy();

            } else if (e.getReportingBody() instanceof Mario) {
                System.out.println("Going to next level");
                e.getReportingBody().destroy();
            }
//        if (e.getOtherBody() == smallboo) {
//            if (e.getReportingBody() instanceof Yoshi) {
//                e.getReportingBody().destroy();
//            }
        }

    }
}

/* this class causes collisions to occur between the ghost and the coins,
yoshi, toad and mario

it also allows yoshi to collide with the coins so that it is harder for the 
player to collect coins */
