package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Toad extends DynamicBody {
    private static final Shape toadShape = new PolygonShape(
    -0.61f,-1.45f, 0.83f,-1.44f, 0.83f,1.19f, 0.28f,1.45f, -0.27f,1.45f, -0.94f,1.13f, -0.95f,-0.88f);
    private static final BodyImage image
            = new BodyImage("data/toad.png", 4f);
    
    public Toad(World world) {
        super(world, toadShape);
        addImage(image);
        
    }
}

// this class creates toad