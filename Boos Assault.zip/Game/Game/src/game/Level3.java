package game;

import city.cs.engine.*;
import java.awt.Color;
import org.jbox2d.common.Vec2;

public class Level3 extends GameLevel {

    /**
     * Populate the world.
     */
    @Override
    public void populate(Game game) {
        super.populate(game);

        // create a platform
        Shape Wall = new BoxShape(0.5f, 10);
        Body middleWall = new StaticBody(this, Wall);
        middleWall.setFillColor(Color.blue);
        middleWall.setPosition(new Vec2(0, -5));

        Shape Platform = new BoxShape(4.5f, 0.5f);
        Body platform1 = new StaticBody(this, Platform);
        platform1.setFillColor(Color.blue);
        platform1.setPosition(new Vec2(-10f, -3.5f));

        Body platform2 = new StaticBody(this, Platform);
        platform2.setFillColor(Color.blue);
        platform2.setPosition(new Vec2(9, -1));
    }

    @Override
    public Vec2 startPosition() {
        return new Vec2(-2, -10.8f);
    }

    @Override
    public Vec2 marioPosition() {
        return new Vec2(10, -10);
    }

    @Override
    public Vec2 yoshiPosition() {
        return new Vec2(9, -10);
    }

    @Override
    public Vec2 toadPosition() {
        return new Vec2(-11, -3);
    }

    @Override
    public Vec2 oneupPosition() {
        return new Vec2(-10.4f, -12);
    }

    @Override
    public Vec2 coinsPosition() {
        return new Vec2(-7, -3);
    }

    @Override
    public boolean isCompleted() {
        return true;
    }
}

// this class contains the positions of the bodies used in level 3

