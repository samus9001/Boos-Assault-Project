
package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Lives extends DynamicBody {
    private static final Shape oneupShape = new PolygonShape(
-0.774f,-0.947f, 1.091f,-0.947f, 1.086f,0.588f, 0.465f,0.955f, -0.432f,0.963f, -1.091f,0.609f, -1.095f,-0.551f);

    private static final BodyImage image
            = new BodyImage("data/oneup.png", 2f);
    
    public Lives(World world) {
        super(world, oneupShape);
        addImage(image);
}
}

//this class creates the lives pickup