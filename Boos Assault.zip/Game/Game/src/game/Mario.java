package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Mario extends DynamicBody {
    private static final Shape marioShape = new PolygonShape(
    -0.89f,-1.83f, 0.78f,-1.83f, 1.18f,-1.37f, 1.07f,1.39f, 0.37f,1.9f, -0.41f,1.9f, -1.16f,1.05f, -1.12f,-1.57f);
    private static final BodyImage image 
        = new BodyImage("data/mario.gif", 4f);
    
    public Mario(World world) {
        super(world, marioShape);
        addImage(image);
    
}
}
    
// this class creates mario