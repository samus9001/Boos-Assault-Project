package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Level1 extends GameLevel {

    /**
     * Populate the world.
     */
    @Override
    public void populate(Game game) {
        super.populate(game);
    }

    @Override
    public Vec2 startPosition() {
        return new Vec2(-10.4f, -10.8f);
    }

    @Override
    public Vec2 marioPosition() {
        return new Vec2(11, -10.8f);
    }

    @Override
    public Vec2 yoshiPosition() {
        return new Vec2(7, -10.8f);
    }

    @Override
    public Vec2 toadPosition() {
        return new Vec2(20, -20);
    }

    @Override
    public Vec2 oneupPosition() {
        return new Vec2(20, -20);
    }

    @Override
    public Vec2 coinsPosition() {
        return (new Vec2(-5, -12));
    }

    @Override
    public boolean isCompleted() {
        return true;
    }
}

// this class contains the positions of the bodies used in level 1
