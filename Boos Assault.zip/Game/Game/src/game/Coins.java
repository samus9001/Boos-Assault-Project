package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Coins extends DynamicBody {

    private static final Shape coinshape = new PolygonShape(
            -0.111f, -0.455f, 0.11f, -0.458f, 0.305f, -0.341f, 0.303f, 0.218f, 0.105f, 0.449f, -0.089f, 0.455f, -0.305f, 0.221f, -0.298f, -0.352f);
    private static final BodyImage image
            = new BodyImage("data/coins.gif", 1f);

    public Coins(World world) {
        super(world, coinshape);
        addImage(image);
    }
}

   
// this class creates the coins pickup
