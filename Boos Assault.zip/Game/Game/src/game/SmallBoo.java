package game;

import city.cs.engine.*;

public class SmallBoo extends DynamicBody {
    
    private static final float radius = 0.5f;
    private static final Shape smallbooShape = new CircleShape(radius);
    private static final BodyImage booImage =
        new BodyImage("data/smallboo.gif", 2*radius);

    public SmallBoo(World world) {
        super(world, smallbooShape);
        addImage(booImage);
    }
}

/* this class creates the projectile boo */