package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Yoshi extends Walker {

    private static final Shape yoshiShape = new PolygonShape(
    -0.65f,-1.97f, 1.16f,-1.97f, 1.24f,-0.27f, -0.05f,1.85f, -1.19f,1.86f, -1.93f,0.7f, -1.93f,0.2f, -1.07f,-1.63f);
    private static final BodyImage image
            = new BodyImage("data/yoshi.gif", 4f);

    private int coinsCount;
    
    public Yoshi(World world) {
        super(world, yoshiShape);
        addImage(image);
        coinsCount = 0;

    }

    public int getCoinsCount() {
        return coinsCount;
    }

    public void incrementCoinsCount() {
        coinsCount++;

    } 
}

// this class creates yoshi and allows him to pickup coins
