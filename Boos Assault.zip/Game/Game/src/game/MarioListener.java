package game;

import city.cs.engine.*;

public class MarioListener implements CollisionListener {

    private Game game;

    public MarioListener(Game game) {
        this.game = game;
    }

    @Override
    public void collide(CollisionEvent e) {
        Boo boo = game.getBoo();
        if (e.getOtherBody() == boo && game.isCurrentLevelCompleted()) {
            System.out.println("Mario Defeated, Level Complete!");
            game.goNextLevel();
        }
    }
}

/* When Boo collides with Mario, the level is complete causing the game
to advance to the next level */
