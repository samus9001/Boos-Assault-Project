package game;

import city.cs.engine.*;
import java.awt.BorderLayout;
import javax.swing.JFrame;

public class Game {

    /**
     * The World in which the bodies move and interact.
     */
    private GameLevel world;

    /**
     * A graphical display of the world (a specialized JPanel).
     */
    private UserView view;

    private int level;

    private Controls controls;

    private GamePanel panel;

    /**
     * Initialize a new Game.
     */
    public Game() {

        // make the world
        level = 1;
        world = new Level1();
        world.populate(this);

        // make a view
        view = new Background(world, this, 500, 500);
        view.addMouseListener(new ShootSmallBoo(view));
        panel = new GamePanel(this);

        // display the view in a frame
        JFrame frame = new JFrame("Boo's Assault");

        // quit the application when the game window is closed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        // display the world in the window
        frame.add(view);
        frame.add(panel, BorderLayout.SOUTH);
        // don't let the game window be resized
        frame.setResizable(false);
        // size the game window to fit the world view
        frame.pack();
        // make the window visible
        frame.setVisible(true);
        // get keyboard focus
        frame.requestFocus();
        // give keyboard focus to the frame whenever the mouse enters the view

        controls = new Controls(world.getBoo());
        frame.addKeyListener(controls);

        // start!
        world.start();
    }

    /**
     * The player in the current level.
     */
    public Boo getBoo() {
        return world.getBoo();
    }

    public GameLevel getWorld() {
        return world;
    }

    /**
     * Is the current level of the game finished?
     */
    public boolean isCurrentLevelCompleted() {
        return world.isCompleted();
    }

    /**
     * Advance to the next level of the game.
     */
    public void goNextLevel() {
        world.stop();
        level++;
        if (level == 2) {
            // get a new world
            world = new Level2();
            // fill it with bodies
            world.populate(this);
            // switch the keyboard control to the new player
            controls.setBody(world.getBoo());
            // show the new world in the view
            view.setWorld(world);
            world.start();
        } else if (level == 3) {
            // get a new world
            world = new Level3();
            // fill it with bodies
            world.populate(this);
            // switch the keyboard control to the new player
            controls.setBody(world.getBoo());
            // show the new world in the view
            view.setWorld(world);
            world.start();
        } else {
            System.exit(0);
        }
    }

    /**
     * Run the game.
     */
    public static void main(String[] args) {
        new Game();
    }

}

// this class creates the world and the levels