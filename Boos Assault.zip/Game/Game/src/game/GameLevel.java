package game;

import city.cs.engine.*;
import java.awt.Color;
import org.jbox2d.common.Vec2;

public abstract class GameLevel extends World {

    private Boo boo;
    private Mario mario;
    private Yoshi yoshi;
    private Coins coins;
    private Toad toad;
    private Lives oneup;
    private SmallBoo smallboo;

    public Boo getBoo() {
        return boo;
    }

    /**
     * Populate the world of this level
     */
    public void populate(Game game) {

        // create the ground
        Shape Ground = new BoxShape(13, 0.5f);
        Body ground = new StaticBody(this, Ground);
        ground.setFillColor(Color.black);
        ground.setPosition(new Vec2(0, -12.8f));

        // create the ceiling
        Shape Ceiling = new BoxShape(13, 0.5f);
        Body ceiling = new StaticBody(this, Ceiling);
        ceiling.setFillColor(Color.black);
        ceiling.setPosition(new Vec2(0, 12.8f));

        // create a wall
        Shape Wall = new BoxShape(0.5f, 15);
        Body leftWall = new StaticBody(this, Wall);
        leftWall.setFillColor(Color.black);
        leftWall.setPosition(new Vec2(-12.8f, -2));

        Body rightWall = new StaticBody(this, Wall);
        rightWall.setFillColor(Color.black);
        rightWall.setPosition(new Vec2(12.8f, -2));

        boo = new Boo(this);
        boo.setPosition(startPosition());

        mario = new Mario(this);
        mario.setPosition(marioPosition());
        //allows the next level to start when a collision happens with mario
        mario.addCollisionListener(new MarioListener(game));
        //allows boo to collide with mario
        mario.addCollisionListener(new Collisions(boo));

        yoshi = new Yoshi(this);
        yoshi.setPosition(yoshiPosition());
        yoshi.startWalking(-0.8f);
        //allows boo to collide with yoshi
        yoshi.addCollisionListener(new Collisions(boo));
        //yoshi.addCollisionListener(new Collisions(smallboo));

        toad = new Toad(this);
        toad.setPosition(toadPosition());
        toad.addCollisionListener(new Collisions(boo));

        oneup = new Lives(this);
        oneup.setPosition(oneupPosition());
        oneup.addCollisionListener(new Collisions(boo));

        for (int i = 0; i < 5; i++) {
            coins = new Coins(this);
            coins.setPosition(coinsPosition());
            //make coins collide with boo
            coins.addCollisionListener(new Collisions(boo));
            //make coins collide with yoshi
            coins.addCollisionListener(new Collisions(yoshi));

        }
    }

    /**
     * The initial position of the player.
     */
    public abstract Vec2 startPosition();

    /**
     * The position of Mario.
     */
    public abstract Vec2 marioPosition();

    /**
     * The position of Yoshi.
     */
    public abstract Vec2 yoshiPosition();

    /**
     * The position of Toad.
     */
    public abstract Vec2 toadPosition();

    /**
     * The position of Lives.
     */
    public abstract Vec2 oneupPosition();

    /**
     * The position of Coins.
     */
    public abstract Vec2 coinsPosition();

    /**
     * Is this level complete?
     */
    public abstract boolean isCompleted();
}

// this class stores anything that is used in every level
